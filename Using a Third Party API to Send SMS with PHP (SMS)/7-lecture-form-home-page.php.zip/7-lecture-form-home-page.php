<form action="" method="post">
    <div class="form-group">
        <label for="email">Phone Number</label>
        <input name="number" type="text" class="form-control" id="email">
    </div>
    <div class="form-group">
        <textarea class="form-control" name="message" id="" cols="30" rows="10"></textarea>
    </div>
    <input type="submit" name="submit" class="btn btn-primary btn-block" value="Send Message">
</form>