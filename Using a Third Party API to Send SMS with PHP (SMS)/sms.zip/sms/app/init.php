<?php
session_start();
ob_start();
require '../vendor/autoload.php';
$config = require('config.php');