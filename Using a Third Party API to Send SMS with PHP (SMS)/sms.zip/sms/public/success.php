<?php include "../includes/header.php"; ?>


<h1 class="bg-success">Your account has been verified</h1>




<?php include "../includes/footer.php"; ?>
